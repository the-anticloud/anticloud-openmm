# 36 Advisory Board

**Project:** OPENMM
**Upstream:** https://github.com/SimTk/openmm

Content specific to OPENMM in category CHEMICAL_MANUFACTURING.
